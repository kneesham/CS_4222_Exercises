import UIKit
import Foundation
/// Objective: Create a property wrapper in a SwiftUI application or Playground that trims any input string provided and capitalizes every word in the sentence.

@propertyWrapper
struct TrimmedCappedString {
    // Leading and trailing whitespace and newlines removed
    // All starting letters capitalized.
    private var sentence: String?

    var wrappedValue: String? {
        get { sentence?.capitalized.trimmingCharacters(in: .whitespacesAndNewlines)}
        set { sentence = newValue}
    }
}

struct Title {
    @TrimmedCappedString
    var titleString: String?

    init(titleString: String){
        self.titleString = titleString
    }
}

var t = Title(titleString: "  \t \t \n the internet is a series of tubes \n-ted stevens \n\n     ")

print(t.titleString!)
